# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 5.2.4   | :white_check_mark: |

## Reporting a Vulnerability

If you have found any security vulnerability you can contact us via 
kim.kulling@googlemail.com

